import sys
from teen import main

if __name__ == "__main__":
    main()
