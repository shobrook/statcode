# teen

Teen does XYZ.
When I first started out in web development, I spent too much time Googling different error codes that I'd receive in my stdout logs. This tool makes it easier

Eventually I want to make this the go-to manual for everything HTTP-related.
